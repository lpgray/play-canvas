var RES = {
	imgs : {
		brazilPlayer : 'img/0002.png',
		argentineanPlayer : 'img/0001.png',
		portuguesePlayer : 'img/0003.png',
		course : 'img/area.png',
		keeper : 'img/0004.png',
		ball : 'img/ball.png',
		scoreBoard: 'img/score-board.png'
	},
	imgNumber : 7,
	key : 'abc123',
	sourceCode : 'h5'
}